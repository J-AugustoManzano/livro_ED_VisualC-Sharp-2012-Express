﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cap05_Ex08
{
    class Program
    {
        static void Main(string[] args)
        {

            double V1 = 15.55;
            int V2 = (int)V1;

            Console.WriteLine(V2);

            Console.WriteLine();
            Console.Write("Tecle algo para encerrar... ");
            Console.ReadKey();
  
        }
    }
}
