﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cap07_Ex01
{
    class Class1
    {
        public string NOME;
        public float[] NOTA = new float[4];

    }
}
